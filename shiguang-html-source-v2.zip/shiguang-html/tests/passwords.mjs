// Local test only: rotates visitor codes, restores both configured codes in finally.
import assert from 'node:assert/strict';
import fs from 'node:fs';
const base=process.env.ALBUM_TEST_URL||'http://127.0.0.1:5176';
const vars=Object.fromEntries(fs.readFileSync('.dev.vars','utf8').trim().split(/\r?\n/).filter(line=>line.includes('=')&&!line.trim().startsWith('#')).map(line=>{const i=line.indexOf('=');return [line.slice(0,i).trim(),JSON.parse(line.slice(i+1).trim())];}));
const configured=[vars.ALBUM_CODE,vars.ALBUM_CODE_ALT].filter(Boolean);
assert.equal(configured.length,2,'two visitor codes configured');
assert.ok(configured.every(code=>code.length>=2&&code!=='??'),'Chinese codes retain their encoding');
let checks=0;const pass=(value,label)=>{assert.ok(value,label);checks++;console.log('PASS '+label);};
async function request(path,body,jar='',method='POST'){
  return fetch(base+'/api/'+path,{method,headers:{Origin:base,...(jar?{Cookie:jar}:{}),...(body?{'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined});
}
async function login(code,path='login'){
  const r=await request(path,{code});assert.equal(r.status,200);const data=await r.json();return {role:data.role,jar:r.headers.getSetCookie().map(value=>value.split(';')[0]).join('; ')};
}
const admin=await login(vars.ADMIN_CODE,'admin');
pass(admin.role==='admin','independent management code grants admin role');
try{
  const visitors=[];
  for(const code of configured){const result=await login(code);visitors.push(result);pass(result.role==='visitor','each configured code grants visitor role');}
  for(const code of configured)pass((await request('admin',{code})).status===401,'visitor code cannot unlock management');
  pass((await request('settings',{accessCodes:['越权']},visitors[0].jar,'PATCH')).status===403,'visitor cannot change access codes');
  for(const codes of [[],['字'],[null],Array(11).fill('春风'),[vars.ADMIN_CODE]])pass((await request('settings',{accessCodes:codes},admin.jar,'PATCH')).status===400,'invalid or management code is rejected');
  pass((await request('settings',{accessCodes:['春风','同桌','春风']},admin.jar,'PATCH')).status===200,'admin can save two short Chinese codes with duplicates removed');
  for(const visitor of visitors)pass((await request('session',undefined,visitor.jar,'GET')).status===200&&!(await(await request('session',undefined,visitor.jar,'GET')).json()).authenticated,'replacing codes expires visitor sessions');
  pass((await request('login',{code:configured[0]})).status===401,'replaced deployment code no longer grants access');
  for(const code of ['春风','同桌'])pass((await login(code)).role==='visitor','each saved Chinese code works');
  pass((await request('settings',{accessCode:'归途'},admin.jar,'PATCH')).status===200,'legacy single-code settings remain compatible');
  pass((await login('归途')).role==='visitor','legacy single-code update takes effect');
  pass((await request('login',{code:'春风'})).status===401,'replacing list with one code removes earlier list');
}finally{
  assert.equal((await request('settings',{accessCodes:configured},admin.jar,'PATCH')).status,200,'restore both configured codes');
}
for(const code of configured)pass((await login(code)).role==='visitor','both configured visitor codes restored');
console.log(`${checks} password and role checks passed.`);
