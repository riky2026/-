// Local integration checks; test records and text changes are restored in finally.
import assert from 'node:assert/strict';
import fs from 'node:fs';
const base=process.env.ALBUM_TEST_URL||'http://127.0.0.1:5176',vars=Object.fromEntries(fs.readFileSync('.dev.vars','utf8').trim().split(/\r?\n/).map(line=>{const i=line.indexOf('=');return [line.slice(0,i),JSON.parse(line.slice(i+1))];}));
let checks=0;const pass=(value,label)=>{assert.ok(value,label);checks++;console.log('PASS '+label);};
async function request(path,{method='GET',body,origin=base}={},jar=''){return fetch(base+'/api/'+path,{method,headers:{...(jar?{cookie:jar}:{}),...(method!=='GET'?{Origin:origin}:{}),...(body&&!(body instanceof FormData)?{'Content-Type':'application/json'}:{})},body:body instanceof FormData?body:body?JSON.stringify(body):undefined});}
async function login(code){const r=await request('login',{method:'POST',body:{code}});assert.equal(r.status,200);return r.headers.getSetCookie().map(s=>s.split(';')[0]).join('; ');}
const visitor=await login(vars.ALBUM_CODE),admin=await login(vars.ADMIN_CODE),before=(await(await request('session',{},admin)).json()).settings;
let messageId,memoryId;
try{
  pass((await request('messages')).status===401,'private guestbook requires access');
  pass((await request('messages',{method:'POST',body:{nickname:'Test',body:'Test'}})).status===401,'anonymous visitors cannot leave messages');
  pass((await request('messages',{method:'POST',body:{nickname:'',body:'Test'}},visitor)).status===400,'message nickname is validated');
  pass((await request('messages',{method:'POST',body:{nickname:'Test',body:'x'.repeat(1001)}},visitor)).status===400,'message length is bounded');
  const created=await request('messages',{method:'POST',body:{nickname:'留言验证',body:'想念大家 <script>this is plain text</script>'}},visitor);assert.equal(created.status,201);messageId=(await created.json()).id;
  let message=(await(await request('messages',{},visitor)).json()).messages.find(m=>m.id===messageId);pass(message?.body.includes('<script>'),'messages are durably stored as plain text');
  pass((await request('messages/'+messageId,{method:'DELETE'},visitor)).status===403,'a message author cannot delete their own message');
  pass((await request('messages/'+messageId,{method:'PATCH',body:{nickname:'A',body:'B',revision:message.updatedAt}},visitor)).status===403,'only administrator may rewrite messages');
  pass((await request('messages/'+messageId,{method:'PATCH',body:{nickname:'主人整理',body:'修改后的留言',revision:message.updatedAt}},admin)).status===200,'administrator may edit every message');
  pass((await request('messages/'+messageId,{method:'PATCH',body:{nickname:'A',body:'stale',revision:'stale'}},admin)).status===409,'stale message edits cannot overwrite a newer version');
  pass((await request('settings',{method:'PATCH',body:{copy:{'gate.title':'无权修改'}}},visitor)).status===403,'visitors cannot change page copy');
  pass((await request('settings',{method:'PATCH',body:{copy:{'invalid.key':'x'}}},admin)).status===400,'unknown copy fields are rejected');
  pass((await request('settings',{method:'PATCH',body:{copy:{...before.copy,'gate.title':'验证后的入口文字','dock.write':'写下我们的故事'}}},admin)).status===200,'administrator may save page and button copy');
  const publicSettings=(await(await request('session')).json()).settings;pass(publicSettings.copy['gate.title']==='验证后的入口文字'&&publicSettings.copy['dock.write']==='写下我们的故事','custom copy survives a fresh visitor session');
  const form=new FormData();for(const [key,value] of Object.entries({title:'权限验证回忆',body:'临时测试内容',nickname:'验证作者',category:'primary'}))form.set(key,value);
  const memory=await request('memories',{method:'POST',body:form},visitor);assert.equal(memory.status,201);memoryId=(await memory.json()).id;
  pass((await request('memories/'+memoryId,{method:'DELETE'},visitor)).status===403,'a memory author cannot delete their own story');
  const list=(await(await request('memories',{},visitor)).json()).memories;pass(list.find(m=>m.id===memoryId)?.canDelete===false,'visitor UI receives no deletion capability');
  if(!before.hasBackground)pass((await request('music',{},visitor)).status===404,'no default music is supplied before owner upload');
  pass((await request('messages',{method:'POST',origin:'https://example.invalid',body:{nickname:'A',body:'B'}},visitor)).status===403,'guestbook rejects cross-origin writes');
}finally{
  assert.equal((await request('settings',{method:'PATCH',body:{copy:before.copy||{}}},admin)).status,200);
  if(messageId)assert.equal((await request('messages/'+messageId,{method:'DELETE'},admin)).status,200);
  if(memoryId)assert.equal((await request('memories/'+memoryId,{method:'DELETE'},admin)).status,200);
}
console.log(`${checks} customization and authorization checks passed; test data cleaned up.`);
