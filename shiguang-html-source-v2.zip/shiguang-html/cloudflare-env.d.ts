/// <reference types="@cloudflare/workers-types" />
declare namespace Cloudflare {
  interface Env {
    DB:D1Database;
    BUCKET:R2Bucket;
    ALBUM_CODE:string;
    ALBUM_CODE_ALT?:string;
    ADMIN_CODE:string;
    APP_SECRET:string;
  }
}
