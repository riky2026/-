import './environment.mjs';
import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {projectRoot} from './environment.mjs';

process.chdir(projectRoot);
const wrangler=path.join(projectRoot,'node_modules','wrangler','bin','wrangler.js');
const configPath=path.join(projectRoot,'wrangler.jsonc');
const loadConfig=()=>JSON.parse(fs.readFileSync(configPath,'utf8'));
function command(args,{capture=false}={}){
  const result=spawnSync(process.execPath,[wrangler,...args],{cwd:projectRoot,encoding:'utf8',stdio:capture?['ignore','pipe','pipe']:'inherit',env:process.env});
  if(result.error)throw result.error;
  if(result.status!==0){if(capture)process.stderr.write(result.stderr||result.stdout||'');throw new Error('Cloudflare command failed: '+args.slice(0,3).join(' '));}
  return result.stdout||'';
}
function readSecrets(){
  const values={},allowed=['ALBUM_CODE','ALBUM_CODE_ALT','ADMIN_CODE','APP_SECRET'];
  for(const line of fs.readFileSync(path.join(projectRoot,'.dev.vars'),'utf8').split(/\r?\n/)){
    if(!line.trim()||line.trim().startsWith('#'))continue;
    const index=line.indexOf('=');if(index<0)continue;
    const key=line.slice(0,index).trim();if(!allowed.includes(key))continue;
    const raw=line.slice(index+1).trim();values[key]=raw.startsWith('"')?JSON.parse(raw):raw.startsWith("'")?raw.slice(1,-1):raw;
  }
  const visitors=[values.ALBUM_CODE,...(values.ALBUM_CODE_ALT?[values.ALBUM_CODE_ALT]:[])];
  if(visitors.some(code=>typeof code!=='string'||code.length<2||code.length>128)||typeof values.ADMIN_CODE!=='string'||values.ADMIN_CODE.length<8||values.ADMIN_CODE.length>128||typeof values.APP_SECRET!=='string'||values.APP_SECRET.length<32||visitors.includes(values.ADMIN_CODE))throw new Error('访问口令需要 2 到 128 个字符，管理口令至少 8 个字符且与访问口令不同，APP_SECRET 至少 32 位。');
  return values;
}
const secrets=readSecrets(),config=loadConfig();
const identity=JSON.parse(command(['whoami','--json'],{capture:true}));
if(!identity.accounts?.some(account=>account.id===config.account_id))throw new Error('当前登录账号不属于指定 Cloudflare 账户，请重新运行 pnpm login。');
console.log('Account verified: '+config.account_id);

// Inspect storage first so an R2 activation requirement is shown before provisioning.
const bucketOutput=command(['r2','bucket','list','--config',configPath],{capture:true});
const bucketName=config.r2_buckets[0].bucket_name;
const bucketExists=bucketOutput.split(/\r?\n/).some(line=>line.match(/^\s*name:\s*(\S+)\s*$/)?.[1]===bucketName)||(()=>{try{const parsed=JSON.parse(bucketOutput);return (Array.isArray(parsed)?parsed:parsed.buckets||[]).some(bucket=>bucket.name===bucketName);}catch{return false;}})();
const listDatabases=()=>JSON.parse(command(['d1','list','--json','--config',configPath],{capture:true}));
let database=listDatabases().find(db=>db.name===config.d1_databases[0].database_name);
if(!database){command(['d1','create',config.d1_databases[0].database_name,'--location','apac','--config',configPath]);database=listDatabases().find(db=>db.name===config.d1_databases[0].database_name);}
if(!database?.uuid)throw new Error('D1 database creation could not be verified.');
if(!bucketExists)command(['r2','bucket','create',bucketName,'--location','apac','--config',configPath]);
config.d1_databases[0].database_id=database.uuid;
fs.writeFileSync(configPath,JSON.stringify(config,null,2)+'\n');
command(['d1','migrations','apply',config.d1_databases[0].database_name,'--remote','--config',configPath]);
const build=spawnSync(process.execPath,['scripts/build.mjs'],{cwd:projectRoot,stdio:'inherit',env:process.env});
if(build.error)throw build.error;if(build.status!==0)throw new Error('Build failed; nothing was deployed.');
const secretPath=path.join(projectRoot,'.wrangler','deploy-secrets.json');
try{
  fs.writeFileSync(secretPath,JSON.stringify(secrets),{mode:0o600});
  command(['deploy','--config','wrangler.jsonc','--secrets-file',secretPath]);
}finally{if(fs.existsSync(secretPath))fs.unlinkSync(secretPath);}
console.log('Worker deployed. Verify the returned test URL before switching yumiyumi.eu.cc.');
