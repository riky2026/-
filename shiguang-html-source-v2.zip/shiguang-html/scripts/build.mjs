import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
const require=createRequire(path.join(root,'package.json'));
let esbuild;try{esbuild=require('esbuild');}catch{esbuild=createRequire(require.resolve('wrangler/package.json'))('esbuild');}
const cssFile=path.join(root,'frontend/app/globals.css');
const appFile=path.join(root,'frontend/app/album.tsx');
const checkApiContent={name:'check-api-content',setup(build){build.onLoad({filter:/[/\\]frontend[/\\]lib[/\\]types\.ts$/},async args=>{
  let contents=await fs.promises.readFile(args.path,'utf8');
  contents=contents.replace("if(!response.ok)throw", "if(value?.error&&response.ok)throw new Error(value.error);if(!response.ok)throw");
  return {contents,loader:'ts'};
});}};
const client=await esbuild.build({
  stdin:{contents:`import React from 'react';import {createRoot} from 'react-dom/client';import Album from ${JSON.stringify(appFile)};import ${JSON.stringify(cssFile)};createRoot(document.getElementById('app')).render(<Album/>);`,resolveDir:root,sourcefile:'html-client.tsx',loader:'tsx'},
  bundle:true,write:false,outfile:'album.js',platform:'browser',format:'iife',jsx:'automatic',minify:true,target:'es2020',define:{'process.env.NODE_ENV':'"production"'},legalComments:'inline',plugins:[checkApiContent],
});
const server=await esbuild.build({stdin:{contents:`import React from 'react';import {renderToString} from 'react-dom/server';import Album from ${JSON.stringify(appFile)};export default renderToString(<Album/>);`,resolveDir:root,sourcefile:'html-initial.tsx',loader:'tsx'},bundle:true,write:false,platform:'node',format:'cjs',jsx:'automatic',external:['react','react-dom/server'],define:{'process.env.NODE_ENV':'"production"'},plugins:[checkApiContent]});
const initialModule={exports:{}};new Function('require','module','exports',server.outputFiles[0].text)(require,initialModule,initialModule.exports);
const initialHtml=initialModule.exports.default;
const js=client.outputFiles.find(file=>file.path.endsWith('.js')).text.replace(/<\/script/gi,'<\\/script');
const css=client.outputFiles.find(file=>file.path.endsWith('.css')).text.replace(/<\/style/gi,'<\\/style');
const html=`<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="description" content="属于我们的时光纪念册：照片、文字、音乐与朋友的留言。">
  <title>时光纪念册</title>
  <!-- 样式和页面脚本均已内嵌，页面无需加载外部脚本或字体。 -->
  <style>${css}</style>
</head>
<body>
  <div id="app">${initialHtml}</div>
  <noscript>请在支持脚本的浏览器中打开纪念册。</noscript>
  <!-- 多人共享数据通过同域名 /api/ 接口保存；配套后台见 worker.mjs。 -->
  <script>${js}</script>
</body>
</html>
`;
fs.mkdirSync(path.join(root,'public'),{recursive:true});fs.writeFileSync(path.join(root,'public/index.html'),html);
await esbuild.build({entryPoints:[path.join(root,'src/worker.ts')],bundle:true,outfile:path.join(root,'worker.mjs'),platform:'neutral',format:'esm',target:'es2022',external:['cloudflare:workers'],minify:false,legalComments:'inline'});
console.log('Built public/index.html with embedded styles/scripts and worker.mjs.');
