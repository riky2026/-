# 时光纪念册 · HTML 版

`public/index.html` 就是完整 HTML 页面，样式和脚本全部内嵌。它保留手机上下翻页、无装饰背景、多照片带边框展示和放大、下移文案、音乐、最后一页留言及管理后台。

## 文件说明

- `public/index.html`：可以直接交付的 HTML 前端。
- `worker.mjs`：可直接部署的 Cloudflare 后台，用于安全口令验证、共享照片、音乐和留言。
- `frontend/`：页面的可读源文件；修改后运行 `npm run build` 重新生成 HTML。
- `lib/`、`src/worker.ts`：后台的可读源文件。
- `drizzle/`：D1 数据库迁移。
- `wrangler.jsonc`：Cloudflare Workers、D1、R2 配置。

HTML 文件中不包含真实口令或密钥。只上传 HTML 可以显示入口页，但要使用登录、多人上传、留言和后台管理，需同时部署 Worker、D1 和 R2，不能当成纯静态网页单独发布。

## 本地运行

需要 Node.js 22.13 或更新版本。

```powershell
npm install
Copy-Item .env.example .dev.vars
# 编辑 .dev.vars，设置不同的访问口令、管理口令和至少 32 位随机 APP_SECRET。
npm run build
node node_modules/wrangler/bin/wrangler.js d1 migrations apply DB --local
npm run dev
```

打开 `http://localhost:5176`。

## 部署到 Cloudflare

```powershell
npm run login
npm run deploy
```

部署脚本会验证账号，创建或复用 D1/R2 资源、应用迁移并发布 HTML 和后台。配置中的账号为你此前提供的 Cloudflare 账号，目标域名是 `yumiyumi.eu.cc`。部署后仍需在 Cloudflare 给这个 Worker 绑定目标域名；先验证新版本，再切换现有域名。

`.dev.vars`、OAuth 登录文件、用户上传数据及本地测试数据均不包含在交付包内。

访问口令支持中文，每个 2 到 128 个字符。部署时用 `ALBUM_CODE` 配置第一个、可选的 `ALBUM_CODE_ALT` 配置第二个；`ADMIN_CODE` 单独配置管理口令。后台也可填写多个访问口令（每行一个或用逗号分隔），保存会替换全部访问口令并让朋友重新登录。后台保存的口令优先于部署环境中的访问口令。
