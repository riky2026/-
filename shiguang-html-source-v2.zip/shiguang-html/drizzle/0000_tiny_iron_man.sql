CREATE TABLE `assets` (
	`id` text PRIMARY KEY NOT NULL,
	`memory_id` text,
	`object_key` text NOT NULL,
	`kind` text NOT NULL,
	`size` integer NOT NULL,
	`position` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `assets_memory_idx` ON `assets` (`memory_id`);--> statement-breakpoint
CREATE TABLE `attempts` (
	`key` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL,
	`expires` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `authors` (
	`id` text PRIMARY KEY NOT NULL,
	`token_hash` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `authors_token_hash_unique` ON `authors` (`token_hash`);--> statement-breakpoint
CREATE TABLE `memories` (
	`id` text PRIMARY KEY NOT NULL,
	`author_id` text NOT NULL,
	`nickname` text NOT NULL,
	`title` text NOT NULL,
	`body` text NOT NULL,
	`category` text NOT NULL,
	`happened_at` text NOT NULL,
	`tags` text NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`author_id` text NOT NULL,
	`role` text NOT NULL,
	`expires` integer NOT NULL,
	`version` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `settings` (
	`key` text PRIMARY KEY NOT NULL,
	`value` text NOT NULL
);
