export class ApiError extends Error {
  status: number;
  constructor(message: string, status = 400) { super(message); this.status = status; }
}
export const categories = ['primary','middle','high','friends'] as const;
export async function digest(value: string) {
  return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))),b=>b.toString(16).padStart(2,'0')).join('');
}
export function safeEqual(a: string,b: string) { let diff=a.length^b.length;for(let i=0;i<Math.max(a.length,b.length);i++)diff|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0);return diff===0; }
export function randomToken(){ return Array.from(crypto.getRandomValues(new Uint8Array(32)),b=>b.toString(16).padStart(2,'0')).join(''); }
export function text(value: unknown,max: number,required=false){
  if(typeof value!=='string')value='';const s=(value as string).trim();
  if((required&&!s)||s.length>max)throw new ApiError(required&&!s?'请填写必填内容。':`内容最多 ${max} 字。`);return s;
}
export function accessCodes(value: unknown){
  if(!Array.isArray(value)||value.length<1||value.length>10)throw new ApiError('请填写 1 到 10 个访问口令。');
  const codes=value.map(code=>{if(typeof code!=='string')throw new ApiError('访问口令格式不正确。');const clean=code.trim();if(clean.length<2||clean.length>128)throw new ApiError('每个访问口令需要 2 到 128 个字符。');return clean;});
  return [...new Set(codes)];
}
export function validateMemory(input: Record<string,unknown>){
  const title=text(input.title,80,true),nickname=text(input.nickname,30,true),body=text(input.body,5000);
  const category=text(input.category,20);if(!categories.includes(category as any))throw new ApiError('请选择正确的回忆分类。');
  const happenedAt=text(input.happenedAt,10);
  if(happenedAt&&(!/^\d{4}-\d{2}-\d{2}$/.test(happenedAt)||Number.isNaN(Date.parse(happenedAt))||new Date(happenedAt).toISOString().slice(0,10)!==happenedAt))throw new ApiError('请选择有效的日期。');
  const tags=[...new Set(text(input.tags,400).split(/[,，、\n]/).map(x=>x.trim()).filter(Boolean))];
  if(tags.length>10||tags.some(x=>x.length>30))throw new ApiError('最多填写 10 位朋友，每个名字最多 30 字。');
  return {title,nickname,body,category,happenedAt,tags};
}
export function fileKind(bytes: Uint8Array,declared: string){
  const s=(start:number,end:number)=>String.fromCharCode(...bytes.slice(start,end));
  let kind='';
  if(bytes[0]===0xff&&bytes[1]===0xd8&&bytes[2]===0xff)kind='image/jpeg';
  else if(s(0,8)==='\x89PNG\r\n\x1a\n')kind='image/png';
  else if(s(0,4)==='RIFF'&&s(8,12)==='WEBP')kind='image/webp';
  else if(s(0,3)==='ID3'||(bytes[0]===0xff&&(bytes[1]&0xe0)===0xe0))kind='audio/mpeg';
  else if(s(4,8)==='ftyp'&&['audio/mp4','audio/x-m4a'].includes(declared))kind='audio/mp4';
  if(!kind||(!kind.startsWith('audio/')&&declared!==kind))throw new ApiError('文件格式不支持，请使用 JPG、PNG、WebP 照片或 MP3、M4A 音乐。');
  return kind;
}
export function parseRange(header:string,size:number){
  const match=/^bytes=(\d*)-(\d*)$/.exec(header);if(!match||(!match[1]&&!match[2]))throw new ApiError('无效的音频范围。',416);
  let start=match[1]?Number(match[1]):Math.max(0,size-Number(match[2]));
  let end=match[1]?(match[2]?Math.min(Number(match[2]),size-1):size-1):size-1;
  if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<0||start>=size||end<start)throw new ApiError('无效的音频范围。',416);
  return {offset:start,length:end-start+1};
}
export function cookieValue(request: Request,name: string){return request.headers.get('cookie')?.split(';').map(x=>x.trim()).find(x=>x.startsWith(name+'='))?.slice(name.length+1)||'';}
export function cookie(request:Request,name:string,value:string,days:number){return `${name}=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${Math.floor(days*86400)}${new URL(request.url).protocol==='https:'?'; Secure':''}`;}
export async function boundedForm(request:Request){
  const limit=32*1024*1024;if(Number(request.headers.get('content-length')||0)>limit)throw new ApiError('每次发布附件合计不能超过 30 MB。',413);
  const reader=request.body?.getReader();if(!reader)throw new ApiError('没有提交内容。');
  const chunks:Uint8Array[]=[];let total=0;
  while(true){const {done,value}=await reader.read();if(done)break;total+=value.length;if(total>limit){await reader.cancel();throw new ApiError('每次发布附件合计不能超过 30 MB。',413);}chunks.push(value);}
  const bytes=new Uint8Array(total);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
  return new Request(request.url,{method:'POST',headers:{'content-type':request.headers.get('content-type')||''},body:bytes}).formData();
}
