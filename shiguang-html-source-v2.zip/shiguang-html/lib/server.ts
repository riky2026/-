import { env as bindings } from 'cloudflare:workers';
import {accessCodes,ApiError,boundedForm,cookie,cookieValue,digest,fileKind,parseRange,randomToken,safeEqual,text,validateMemory} from './security';
import {copyFields} from './copy';

type Runtime={DB:D1Database;BUCKET:R2Bucket;ALBUM_CODE:string;ALBUM_CODE_ALT?:string;ADMIN_CODE:string;APP_SECRET:string};
type Session={token_hash:string;author_id:string;role:string;expires:number;version:number};
type Asset={id:string;memory_id:string|null;object_key:string;kind:string;size:number;position:number};
type MemoryRow={id:string;author_id:string;nickname:string;title:string;body:string;category:string;happened_at:string;tags:string;created_at:string;updated_at:string};
const defaults={title:'时光纪念册',welcome:'把散落在岁月里的我们，重新收藏在一起。',showExamples:'true',accessVersion:'1'};
const noCache={'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'};
function json(value:unknown,status=200){return new Response(JSON.stringify(value),{status,headers:{...noCache,'Content-Type':'application/json; charset=utf-8'}});}
function runtime(){const env=bindings as unknown as Runtime;if(!env.DB||!env.BUCKET||!env.ALBUM_CODE||!env.ADMIN_CODE||!env.APP_SECRET)throw new ApiError('纪念册正在配置中，请稍后再来。',503);return env;}
async function settings(env:Runtime){const {results}=await env.DB.prepare('SELECT key,value FROM settings').all<{key:string;value:string}>();return {...defaults,...Object.fromEntries(results.map(x=>[x.key,x.value]))} as Record<string,string>;}
function displaySettings(s:Record<string,string>){let copy:Record<string,string>={};try{copy=JSON.parse(s.copy||'{}');}catch{}return {title:s.title,welcome:s.welcome,showExamples:s.showExamples==='true',hasBackground:!!s.backgroundAssetId,copy};}
async function current(request:Request,env:Runtime,s:Record<string,string>){
  const token=cookieValue(request,'album_session');if(!token)return null;
  const session=await env.DB.prepare('SELECT * FROM sessions WHERE token_hash=?').bind(await digest(token)).first<Session>();
  return session&&session.expires>Date.now()&&session.version===Number(s.accessVersion)?session:null;
}
function requireAdmin(session:Session){if(session.role!=='admin')throw new ApiError('这项操作需要管理口令。',403);}
async function login(request:Request,env:Runtime,s:Record<string,string>,adminOnly=false){
  const ip=await digest(env.APP_SECRET+':ip:'+(request.headers.get('CF-Connecting-IP')||'local'));
  const attempt=await env.DB.prepare('SELECT count,expires FROM attempts WHERE key=?').bind(ip).first<{count:number;expires:number}>();
  if(attempt&&attempt.expires>Date.now()&&attempt.count>=8)throw new ApiError('口令尝试次数较多，请 15 分钟后再试。',429);
  const input=await request.json() as Record<string,unknown>;const code=text(input.code,128,true);
  const hash=await digest(env.APP_SECRET+':code:'+code),admin=safeEqual(hash,await digest(env.APP_SECRET+':code:'+env.ADMIN_CODE));
  const hashes:string[]=s.accessHashes?JSON.parse(s.accessHashes):s.accessHash?[s.accessHash]:await Promise.all([env.ALBUM_CODE,env.ALBUM_CODE_ALT].filter((code):code is string=>!!code).map(code=>digest(env.APP_SECRET+':code:'+code)));
  const visitor=hashes.reduce((matched,expected)=>safeEqual(hash,expected)||matched,false);
  const good=admin||(!adminOnly&&visitor);
  if(!good){await env.DB.prepare('INSERT INTO attempts(key,count,expires) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN expires<? THEN 1 ELSE count+1 END, expires=CASE WHEN expires<? THEN excluded.expires ELSE expires END').bind(ip,Date.now()+900000,Date.now(),Date.now()).run();throw new ApiError(adminOnly?'管理口令不正确。':'口令不正确，再想想我们之间的暗号。',401);}
  const prior=cookieValue(request,'album_author');let author=prior?await env.DB.prepare('SELECT id FROM authors WHERE token_hash=?').bind(await digest(prior)).first<{id:string}>():null;
  let authorToken=prior;if(!author){authorToken=randomToken();author={id:crypto.randomUUID()};await env.DB.prepare('INSERT INTO authors(id,token_hash) VALUES(?,?)').bind(author.id,await digest(authorToken)).run();}
  const token=randomToken();const old=cookieValue(request,'album_session');
  const statements=[env.DB.prepare('INSERT INTO sessions(token_hash,author_id,role,expires,version) VALUES(?,?,?,?,?)').bind(await digest(token),author.id,admin?'admin':'visitor',Date.now()+7*86400000,Number(s.accessVersion)),env.DB.prepare('DELETE FROM attempts WHERE key=? OR expires<?').bind(ip,Date.now()),env.DB.prepare('DELETE FROM sessions WHERE expires<?').bind(Date.now())];
  if(old)statements.push(env.DB.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await digest(old)));
  await env.DB.batch(statements);
  const response=json({authenticated:true,role:admin?'admin':'visitor',settings:displaySettings(s)});response.headers.append('Set-Cookie',cookie(request,'album_session',token,7));response.headers.append('Set-Cookie',cookie(request,'album_author',authorToken,365));return response;
}
function expose(row:MemoryRow,assets:Asset[],session:Session){return {id:row.id,title:row.title,body:row.body,category:row.category,nickname:row.nickname,happenedAt:row.happened_at,tags:JSON.parse(row.tags),createdAt:row.created_at,updatedAt:row.updated_at,canEdit:session.role==='admin'||row.author_id===session.author_id,canDelete:session.role==='admin',assets:assets.map(a=>({id:a.id,kind:a.kind,url:'/api/media/'+a.id,size:a.size}))};}
async function list(env:Runtime,session:Session){
  const [{results:rows},{results:files}]=await Promise.all([env.DB.prepare("SELECT * FROM memories ORDER BY COALESCE(NULLIF(happened_at,''),substr(created_at,1,10)) DESC,created_at DESC").all<MemoryRow>(),env.DB.prepare('SELECT * FROM assets WHERE memory_id IS NOT NULL ORDER BY position').all<Asset>()]);
  return json({memories:rows.map(row=>expose(row,files.filter(a=>a.memory_id===row.id),session))});
}
async function save(request:Request,env:Runtime,session:Session,id?:string){
  const old=id?await env.DB.prepare('SELECT * FROM memories WHERE id=?').bind(id).first<MemoryRow>():null;
  if(id&&!old)throw new ApiError('这条回忆已不存在。',404);
  if(old&&old.author_id!==session.author_id&&session.role!=='admin')throw new ApiError('只能编辑自己发布的回忆。',403);
  const form=await boundedForm(request),input=Object.fromEntries(form.entries()),data=validateMemory(input);
  if(old&&form.get('revision')&&form.get('revision')!==old.updated_at)throw new ApiError('这条回忆刚刚被修改，请重新打开后再编辑。',409);
  const existing=old?(await env.DB.prepare('SELECT * FROM assets WHERE memory_id=? ORDER BY position').bind(old.id).all<Asset>()).results:[];
  let keepIds:string[]=[];try{keepIds=JSON.parse(String(form.get('keepAssets')||'[]'));}catch{throw new ApiError('附件选择无效。');}
  if(!Array.isArray(keepIds)||keepIds.some(id=>typeof id!=='string'||!existing.some(a=>a.id===id)))throw new ApiError('附件选择无效。');
  const kept=existing.filter(a=>keepIds.includes(a.id));
  const photos=form.getAll('photos').filter((x):x is File=>x instanceof File&&x.size>0),audio=form.get('audio');const audioFiles=audio instanceof File&&audio.size>0?[audio]:[];
  if(photos.length+kept.filter(a=>a.kind.startsWith('image/')).length>9)throw new ApiError('每条回忆最多 9 张照片。');
  if(audioFiles.length+kept.filter(a=>a.kind.startsWith('audio/')).length>1)throw new ApiError('每条回忆最多添加一首音乐。');
  if(!data.body&&!photos.length&&!audioFiles.length&&!kept.length)throw new ApiError('写一段回忆，或添加照片、音乐吧。');
  const files=[...photos,...audioFiles];if(files.reduce((n,f)=>n+f.size,0)>30*1024*1024)throw new ApiError('每次发布附件合计不能超过 30 MB。',413);
  const validated:{file:File;kind:string}[]=[];
  for(const file of files){const kind=fileKind(new Uint8Array(await file.slice(0,32).arrayBuffer()),file.type);if(photos.includes(file)&&!kind.startsWith('image/'))throw new ApiError('照片区域只能选择图片。');if(audioFiles.includes(file)&&!kind.startsWith('audio/'))throw new ApiError('音乐区域只能选择音频。');if(file.size>(kind.startsWith('image/')?10:20)*1024*1024)throw new ApiError('单张照片最多 10 MB，单首音乐最多 20 MB。',413);validated.push({file,kind});}
  const memoryId=id||crypto.randomUUID(),now=new Date().toISOString();const added:Asset[]=[];
  try{
    for(const {file,kind} of validated){const asset:Asset={id:crypto.randomUUID(),memory_id:memoryId,object_key:'album/'+crypto.randomUUID(),kind,size:file.size,position:kept.length+added.length};await env.BUCKET.put(asset.object_key,await file.arrayBuffer(),{httpMetadata:{contentType:kind}});added.push(asset);}
    const statements:D1PreparedStatement[]=[];
    if(old)statements.push(env.DB.prepare('UPDATE memories SET nickname=?,title=?,body=?,category=?,happened_at=?,tags=?,updated_at=? WHERE id=?').bind(data.nickname,data.title,data.body,data.category,data.happenedAt,JSON.stringify(data.tags),now,memoryId));
    else statements.push(env.DB.prepare('INSERT INTO memories(id,author_id,nickname,title,body,category,happened_at,tags,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)').bind(memoryId,session.author_id,data.nickname,data.title,data.body,data.category,data.happenedAt,JSON.stringify(data.tags),now,now));
    for(const asset of added)statements.push(env.DB.prepare('INSERT INTO assets(id,memory_id,object_key,kind,size,position) VALUES(?,?,?,?,?,?)').bind(asset.id,memoryId,asset.object_key,asset.kind,asset.size,asset.position));
    for(const asset of existing.filter(a=>!keepIds.includes(a.id)))statements.push(env.DB.prepare('DELETE FROM assets WHERE id=?').bind(asset.id));
    await env.DB.batch(statements);
  }catch(error){await Promise.allSettled(added.map(a=>env.BUCKET.delete(a.object_key)));throw error;}
  await Promise.allSettled(existing.filter(a=>!keepIds.includes(a.id)).map(a=>env.BUCKET.delete(a.object_key)));
  return json({id:memoryId},old?200:201);
}
async function remove(env:Runtime,session:Session,id:string){
  requireAdmin(session);
  const row=await env.DB.prepare('SELECT * FROM memories WHERE id=?').bind(id).first<MemoryRow>();if(!row)throw new ApiError('回忆已不存在。',404);
  const {results}=await env.DB.prepare('SELECT * FROM assets WHERE memory_id=?').bind(id).all<Asset>();
  await env.DB.batch([env.DB.prepare('DELETE FROM assets WHERE memory_id=?').bind(id),env.DB.prepare('DELETE FROM memories WHERE id=?').bind(id)]);
  await Promise.allSettled(results.map(a=>env.BUCKET.delete(a.object_key)));return json({ok:true});
}
async function media(request:Request,env:Runtime,asset:Asset){
  let range:{offset:number;length:number}|undefined=undefined;const header=request.headers.get('Range');try{range=header?parseRange(header,asset.size):undefined;}catch{ return new Response(null,{status:416,headers:{...noCache,'Content-Range':`bytes */${asset.size}`}});}
  const object=await env.BUCKET.get(asset.object_key,range?{range}:undefined);if(!object)throw new ApiError('文件未找到。',404);
  const headers:Record<string,string>={...noCache,'Content-Type':asset.kind,'Accept-Ranges':'bytes','Content-Length':String(range?.length||asset.size),'Content-Disposition':'inline'};
  if(range)headers['Content-Range']=`bytes ${range.offset}-${range.offset+range.length-1}/${asset.size}`;
  return new Response(object.body,{status:range?206:200,headers});
}
async function updateSettings(request:Request,env:Runtime,session:Session,s:Record<string,string>){
  requireAdmin(session);const input=await request.json() as Record<string,unknown>;const values:Record<string,string>={};
  if(input.title!==undefined)values.title=text(input.title,40,true);
  if(input.welcome!==undefined)values.welcome=text(input.welcome,200);
  if(input.showExamples!==undefined){if(typeof input.showExamples!=='boolean')throw new ApiError('设置格式不正确。');values.showExamples=String(input.showExamples);}
  if(input.copy!==undefined){
    if(!input.copy||typeof input.copy!=='object'||Array.isArray(input.copy))throw new ApiError('文字设置格式不正确。');
    const clean:Record<string,string>={};
    for(const [key,value] of Object.entries(input.copy)){if(!Object.hasOwn(copyFields,key)||typeof value!=='string'||value.length>5000)throw new ApiError('文字设置包含无效字段，或单段内容超过 5000 字。');clean[key]=value;}
    if(JSON.stringify(clean).length>180000)throw new ApiError('文字设置内容过长。');values.copy=JSON.stringify(clean);
  }
  if(input.accessCodes!==undefined||(input.accessCode!==undefined&&input.accessCode!=='')){
    const codes=accessCodes(input.accessCodes!==undefined?input.accessCodes:[input.accessCode]);
    const adminHash=await digest(env.ADMIN_CODE);
    for(const code of codes)if(safeEqual(await digest(code),adminHash))throw new ApiError('访问口令不能与管理口令相同。');
    values.accessHashes=JSON.stringify(await Promise.all(codes.map(code=>digest(env.APP_SECRET+':code:'+code))));values.accessVersion=String(Number(s.accessVersion)+1);
  }
  const statements=Object.entries(values).map(([k,v])=>env.DB.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind(k,v));
  if(values.accessVersion){statements.push(env.DB.prepare('DELETE FROM sessions WHERE token_hash<>?').bind(session.token_hash));statements.push(env.DB.prepare('UPDATE sessions SET version=? WHERE token_hash=?').bind(Number(values.accessVersion),session.token_hash));}
  if(statements.length)await env.DB.batch(statements);return json({ok:true,settings:displaySettings({...s,...values})});
}
async function background(request:Request,env:Runtime,session:Session,s:Record<string,string>){
  requireAdmin(session);const form=await boundedForm(request),file=form.get('audio');if(!(file instanceof File)||!file.size)throw new ApiError('请选择一首 MP3 或 M4A 音乐。');if(file.size>20*1024*1024)throw new ApiError('背景音乐最多 20 MB。',413);
  const kind=fileKind(new Uint8Array(await file.slice(0,32).arrayBuffer()),file.type);if(!kind.startsWith('audio/'))throw new ApiError('请选择音频文件。');
  const id=crypto.randomUUID(),key='background/'+crypto.randomUUID();await env.BUCKET.put(key,await file.arrayBuffer(),{httpMetadata:{contentType:kind}});
  try{await env.DB.batch([env.DB.prepare('INSERT INTO assets(id,memory_id,object_key,kind,size,position) VALUES(?,NULL,?,?,?,0)').bind(id,key,kind,file.size),env.DB.prepare("INSERT INTO settings(key,value) VALUES('backgroundAssetId',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").bind(id)]);}catch(error){await env.BUCKET.delete(key);throw error;}
  if(s.backgroundAssetId){const old=await env.DB.prepare('SELECT * FROM assets WHERE id=? AND memory_id IS NULL').bind(s.backgroundAssetId).first<Asset>();if(old){await env.DB.prepare('DELETE FROM assets WHERE id=?').bind(old.id).run();await env.BUCKET.delete(old.object_key).catch(()=>{});}}
  return json({ok:true});
}
async function guestMessages(request:Request,env:Runtime,session:Session,id?:string){
  if(request.method==='GET'&&!id){const {results}=await env.DB.prepare('SELECT id,nickname,body,updated_at AS updatedAt FROM messages ORDER BY created_at ASC,id ASC').all();return json({messages:results});}
  if(request.method==='DELETE'&&id){requireAdmin(session);const result=await env.DB.prepare('DELETE FROM messages WHERE id=?').bind(id).run();if(!result.meta.changes)throw new ApiError('这条留言已不存在。',404);return json({ok:true});}
  if((request.method==='POST'&&!id)||(request.method==='PATCH'&&id)){
    if(id)requireAdmin(session);
    const input=await request.json() as Record<string,unknown>,nickname=text(input.nickname,30,true),body=text(input.body,1000,true),now=new Date().toISOString();
    if(id){
      const result=await env.DB.prepare('UPDATE messages SET nickname=?,body=?,updated_at=? WHERE id=? AND updated_at=?').bind(nickname,body,now,id,text(input.revision,50,true)).run();
      if(!result.meta.changes)throw new ApiError('留言已被修改或删除，请刷新后重试。',409);
    }else{
      const recent=await env.DB.prepare('SELECT count(*) AS total FROM messages WHERE author_id=? AND created_at>?').bind(session.author_id,new Date(Date.now()-60000).toISOString()).first<{total:number}>();
      if((recent?.total||0)>=5)throw new ApiError('留言已收到，请稍等片刻再发送。',429);
      id=crypto.randomUUID();await env.DB.prepare('INSERT INTO messages(id,author_id,nickname,body,created_at,updated_at) VALUES(?,?,?,?,?,?)').bind(id,session.author_id,nickname,body,now,now).run();
    }
    return json({id},request.method==='POST'?201:200);
  }
  throw new ApiError('没有找到这个入口。',404);
}
export async function handleApi(request:Request,path:string[]):Promise<Response>{
  try{
    if(!['GET','HEAD'].includes(request.method)&&request.headers.get('Origin')!==new URL(request.url).origin)throw new ApiError('请从纪念册页面提交操作。',403);
    const env=runtime(),s=await settings(env),session=await current(request,env,s),method=request.method;
    if(path[0]==='session'&&method==='GET')return json({authenticated:!!session,role:session?.role,settings:displaySettings(s)});
    if(path[0]==='login'&&method==='POST')return await login(request,env,s);
    if(path[0]==='admin'&&method==='POST')return await login(request,env,s,true);
    if(!session)throw new ApiError('请先输入口令，打开我们的纪念册。',401);
    if(path[0]==='logout'&&method==='POST'){await env.DB.prepare('DELETE FROM sessions WHERE token_hash=?').bind(session.token_hash).run();const response=json({ok:true});response.headers.append('Set-Cookie',cookie(request,'album_session','',0));return response;}
    if(path[0]==='memories'){
      if(!path[1]&&method==='GET')return await list(env,session);
      if(!path[1]&&method==='POST')return await save(request,env,session);
      if(path[1]&&method==='PATCH')return await save(request,env,session,path[1]);
      if(path[1]&&method==='DELETE')return await remove(env,session,path[1]);
    }
    if(path[0]==='messages')return await guestMessages(request,env,session,path[1]);
    if(path[0]==='media'&&path[1]&&method==='GET'){const asset=await env.DB.prepare('SELECT * FROM assets WHERE id=?').bind(path[1]).first<Asset>();if(!asset)throw new ApiError('文件未找到。',404);return await media(request,env,asset);}
    if(path[0]==='music'&&method==='GET'){
      if(s.backgroundAssetId){const asset=await env.DB.prepare('SELECT * FROM assets WHERE id=?').bind(s.backgroundAssetId).first<Asset>();if(asset)return await media(request,env,asset);}
      throw new ApiError('还没有添加背景音乐。',404);
    }
    if(path[0]==='settings'&&method==='PATCH')return await updateSettings(request,env,session,s);
    if(path[0]==='background'&&method==='POST')return await background(request,env,session,s);
    throw new ApiError('没有找到这个入口。',404);
  }catch(error){if(error instanceof ApiError)return json({error:error.message},error.status);if(error instanceof SyntaxError)return json({error:'提交的内容格式不正确。'},400);console.error('Album request failed:',error instanceof Error?error.message:'unknown');return json({error:'暂时没能完成操作，请稍后重试。'},500);}
}
