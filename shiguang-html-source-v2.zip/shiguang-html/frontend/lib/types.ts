export type Asset={id:string;kind:string;url:string;size:number};
export type Memory={id:string;title:string;body:string;category:string;nickname:string;happenedAt:string;tags:string[];createdAt:string;updatedAt:string;canEdit:boolean;canDelete?:boolean;assets:Asset[];example?:boolean};
export type GuestMessage={id:string;nickname:string;body:string;updatedAt:string};
export type Settings={title:string;welcome:string;showExamples:boolean;hasBackground:boolean;copy?:Record<string,string>};
export type Session={authenticated:boolean;role?:string;settings:Settings};
export const groups=[{id:'primary',name:'小学时光',sub:'最初的我们',year:'CHAPTER 01',color:'#e8d5a9'},{id:'middle',name:'初中时光',sub:'风吹过的盛夏',year:'CHAPTER 02',color:'#b8c5ad'},{id:'high',name:'高中时光',sub:'并肩追过的光',year:'CHAPTER 03',color:'#d9b8a8'},{id:'friends',name:'关于朋友',sub:'很高兴遇见你',year:'CHAPTER 04',color:'#b5c6ce'}];
export const examples:Memory[]=[
  {id:'demo-1',title:'那年夏天，我们毕业了',body:'操场上的风，走廊里的笑声，还有那张总有人闭眼的毕业照。\n\n把你的合照和故事放在这里，让那些年重新有了温度。',category:'high',nickname:'时光小邮差',happenedAt:'2018-06-08',tags:['同桌','那群老朋友'],createdAt:'2018-06-08',updatedAt:'',canEdit:false,assets:[],example:true},
  {id:'demo-2',title:'放学后，再多走一段路',body:'小时候总觉得，放学的路很长。长大以后才发现，最想再走一次的，也是那段路。\n\n这是示例回忆，等你用自己的故事来替换。',category:'primary',nickname:'时光小邮差',happenedAt:'2009-05-20',tags:['发小'],createdAt:'2009-05-20',updatedAt:'',canEdit:false,assets:[],example:true},
  {id:'demo-3',title:'有你们在，平凡也闪闪发光',body:'未必每次见面都有特别的事，但和你们在一起，就足够值得被记录。\n\n写下一个名字、一句记得的话，或者上传最近一次见面的照片吧。',category:'friends',nickname:'时光小邮差',happenedAt:'2024-10-01',tags:['好朋友'],createdAt:'2024-10-01',updatedAt:'',canEdit:false,assets:[],example:true},
  {id:'demo-4',title:'课本里夹着的，不止是书签',body:'一张小纸条，一片秋天的叶子，一句写在课本角落里的悄悄话。\n\n那时觉得微不足道，现在想起来却格外珍贵。',category:'middle',nickname:'时光小邮差',happenedAt:'2013-09-01',tags:['同桌'],createdAt:'2013-09-01',updatedAt:'',canEdit:false,assets:[],example:true}
];
export async function api<T=any>(path:string,options:RequestInit={}):Promise<T>{
  const response=await fetch('/api/'+path,{...options,credentials:'same-origin'});
  const value:any=await response.json().catch(()=>({error:'暂时无法连接，请稍后重试。'}));
  if(!response.ok)throw new Error(value.error||'操作没有完成，请重试。');return value;
}
export const jsonBody=(value:unknown)=>({headers:{'Content-Type':'application/json'},body:JSON.stringify(value)});
