export type CopyField={group:string;label:string;value:string};
const sections:Record<string,[string,string,string][]>= {
  '入口页':[
    ['brand.english','名字下方英文','OUR LITTLE TIME CAPSULE'],['gate.private','私密提示','只属于我们的时光'],['gate.eyebrow','首页英文小标题','A PLACE TO REMEMBER'],
    ['gate.title','首页大标题','有些时光，\n值得反复翻阅。'],['gate.intro','首页介绍','从第一声下课铃，到每一次久别重逢。\n把照片、故事和喜欢的歌，\n留在这本属于我们的纪念册。'],
    ['gate.label','口令提问','还记得，我们之间的暗号吗？'],['gate.placeholder','口令输入提示','输入专属口令'],['gate.enter','进入按钮','进入我们的纪念册'],['gate.connecting','连接提示','正在连接纪念册…'],['gate.opening','打开提示','正在打开时光…'],
    ['gate.music','音乐提示','进入后将尝试播放你添加的音乐，可以随时暂停。'],['gate.note','首页寄语','献给每一个，舍不得忘记的瞬间。'],['gate.footer','首页页脚','时光会走远，故事会留下。'],['gate.footerEnglish','首页页脚英文','MADE FOR THE DAYS WE SHARE']
  ],
  '回忆浏览':[
    ['reader.sample','示例标记','示例回忆'],['reader.up','上滑提示','向上滑，继续翻阅'],['reader.last','最后一段提示','把想说的话，留在最后一页'],['reader.audio','音乐标记','附有音乐'],['reader.photos','照片数量','{count} 张照片'],['reader.with','朋友署名','与 {names}'],['reader.audioOnly','音乐回忆简介','有一首歌，想和你一起听。'],
    ['reader.loading','加载文字','正在翻开我们的故事…'],['reader.error','加载失败标题','故事暂时没有打开'],['reader.retry','重试按钮','重新加载'],['reader.emptyTitle','空白页标题','这一页，等你来写'],['reader.emptyBody','空白页介绍','一张照片、一段文字、一首歌，\n都是故事的开始。'],['reader.emptyEnglish','空白页英文','A NEW PAGE BEGINS'],['reader.first','第一段按钮','写下第一段回忆'],
    ['reader.previous','上一段按钮','上一段回忆'],['reader.next','下一段按钮','下一段回忆'],['reader.position','翻页播报','第 {index} 段，共 {count} 段回忆'],['category.primary','小学名称','小学时光'],['category.middle','初中名称','初中时光'],['category.high','高中名称','高中时光'],['category.friends','朋友名称','关于朋友'],
    ['dock.write','写回忆按钮','写下回忆'],['dock.manage','后台按钮','管理纪念册'],['dock.addMusic','添加音乐按钮','添加音乐'],['dock.musicName','背景音乐名称','我们的背景音乐'],['dock.playing','播放提示','旋律正在轻轻流淌'],['dock.blocked','手动播放提示','点播放，开启音乐'],['dock.paused','暂停提示','属于我们的旋律'],['dock.play','播放按钮','播放背景音乐'],['dock.pause','暂停按钮','暂停背景音乐'],['dock.invite','邀请按钮','邀请朋友'],['dock.exit','离开按钮','合上纪念册'],
    ['notice.saved','回忆保存提示','这段时光，已经替你收藏好了。'],['notice.deleted','回忆删除提示','这段回忆已删除。'],['notice.settings','设置保存提示','纪念册设置已保存。'],['notice.invite','复制链接提示','链接已复制，记得把访问口令私下告诉朋友。'],['notice.copyFailed','复制失败提示','请复制浏览器地址栏中的链接，发给朋友。']
  ],
  '留言结尾':[
    ['guest.eyebrow','留言英文小标题','SOME WORDS STAY FOREVER'],['guest.title','留言标题','把想说的话，留在这里'],['guest.intro','留言介绍','翻到最后，故事还没有结束。\n留一句问候，让朋友知道你来过。'],['guest.empty','还没有留言','还没有留言，来写下第一句问候吧。'],['guest.nickname','留言昵称标签','你的昵称'],['guest.nicknamePlaceholder','留言昵称提示','让朋友知道是你'],['guest.body','留言内容标签','想对大家说的话'],['guest.placeholder','留言输入提示','好久不见，最近还好吗？'],['guest.submit','留言按钮','留下留言'],['guest.sending','留言提交提示','正在送出…'],['guest.sent','留言成功提示','你的留言，已经留在最后一页。'],['guest.back','返回回忆按钮','回到回忆'],['guest.edit','编辑留言按钮','编辑留言'],['guest.delete','删除留言按钮','删除留言'],['guest.confirmDelete','删除留言确认','确定删除这条留言吗？'],['guest.ownerNote','留言权限说明','留言由纪念册主人管理。']
  ],
  '回忆详情与填写':[
    ['detail.title','详情弹窗标题','翻开这一页'],['detail.sample','详情示例标记','示例回忆 · 非真实记录'],['detail.audio','回忆音乐标题','属于这段回忆的旋律'],['detail.edit','编辑回忆按钮','编辑回忆'],['detail.delete','删除回忆按钮','删除回忆'],['detail.deleting','删除中提示','正在删除…'],['detail.confirmDelete','回忆删除确认','确定删除这段回忆吗？照片、文字和附带音乐也会一起删除。'],['detail.sampleNote','示例说明','这是一页示例文字，用来展示纪念册的样子。点「写下回忆」，开始收藏你们自己的照片和故事。'],
    ['editor.new','新建标题','写下一段回忆'],['editor.edit','修改标题','再添几笔回忆'],['editor.intro','填写介绍','照片记住画面，文字留住当时的心情。'],['editor.title','回忆标题标签','给这段回忆起个名字'],['editor.titlePlaceholder','标题提示','比如：那个不想说再见的夏天'],['editor.nickname','作者标签','你的昵称'],['editor.nicknamePlaceholder','作者提示','让朋友知道是你'],['editor.category','分类标签','属于哪段时光'],['editor.body','正文标签','记得那时的故事吗'],['editor.bodyPlaceholder','正文提示','那天发生了什么？谁在身边？有什么一直没说出口的话……'],['editor.friends','朋友标签','一起出现的朋友'],['editor.friendsPlaceholder','朋友提示','多个名字用逗号隔开'],['editor.photos','照片标签','放进几张照片'],['editor.photoLimit','照片限制提示','最多 9 张 · 每张 10 MB'],['editor.addPhoto','添加照片按钮','添加照片'],['editor.audio','回忆配乐标签','给回忆配一首歌'],['editor.audioKept','已添加音乐提示','已添加一首音乐'],['editor.audioHint','音乐限制提示','可选 · MP3 / M4A · 最大 20 MB'],['editor.chooseAudio','选择音乐按钮','选择音乐'],['editor.footer','保存说明','保存后，朋友们就能看见这段回忆。'],['editor.saving','保存中提示','正在收藏…'],['editor.save','保存修改按钮','保存修改'],['editor.create','新回忆保存按钮','收藏这段时光'],['editor.confirmClose','未保存确认','这段回忆还没有保存，确定先离开吗？'],
    ['common.close','关闭按钮','关闭'],['common.save','保存按钮','保存'],['common.cancel','取消按钮','取消'],['common.remove','移除按钮','移除'],['common.edit','编辑按钮','编辑'],['common.deleting','删除中','正在删除…'],['common.saving','保存中','正在保存…'],['common.photo','照片放大标题','照片放大查看']
  ],
  '示例回忆':[
    ['demo.1.title','示例一标题','那年夏天，我们毕业了'],['demo.1.body','示例一正文','操场上的风，走廊里的笑声，还有那张总有人闭眼的毕业照。\n\n把你的合照和故事放在这里，让那些年重新有了温度。'],
    ['demo.2.title','示例二标题','放学后，再多走一段路'],['demo.2.body','示例二正文','小时候总觉得，放学的路很长。长大以后才发现，最想再走一次的，也是那段路。\n\n这是示例回忆，等你用自己的故事来替换。'],
    ['demo.3.title','示例三标题','有你们在，平凡也闪闪发光'],['demo.3.body','示例三正文','未必每次见面都有特别的事，但和你们在一起，就足够值得被记录。\n\n写下一个名字、一句记得的话，或者上传最近一次见面的照片吧。'],
    ['demo.4.title','示例四标题','课本里夹着的，不止是书签'],['demo.4.body','示例四正文','一张小纸条，一片秋天的叶子，一句写在课本角落里的悄悄话。\n\n那时觉得微不足道，现在想起来却格外珍贵。'],['demo.nickname','示例作者','时光小邮差'],['demo.friends','示例朋友','老朋友']
  ]
};
export const copyFields:Record<string,CopyField>=Object.fromEntries(Object.entries(sections).flatMap(([group,fields])=>fields.map(([key,label,value])=>[key,{group,label,value}])));
export function copyText(overrides:Record<string,string>|undefined,key:string,values:Record<string,string|number>={}){
  const text=overrides?.[key]??copyFields[key]?.value??key;
  return text.replace(/\{(\w+)\}/g,(match,name)=>values[name]===undefined?match:String(values[name]));
}
