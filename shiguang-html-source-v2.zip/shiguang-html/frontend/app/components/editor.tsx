'use client';
import {useCallback,useEffect,useMemo,useState} from 'react';
import {groups,Memory,api} from '../../lib/types';
import {Icon,Modal} from './ui';
import {useCopy} from './copy';
export function Editor({memory,category,onClose,onSaved}:{memory?:Memory;category:string;onClose:()=>void;onSaved:()=>void}){
  const t=useCopy();
  const [values,setValues]=useState({title:memory?.title||'',body:memory?.body||'',nickname:memory?.nickname||'',category:memory?.category||(category==='all'?'primary':category),happenedAt:memory?.happenedAt||'',tags:memory?.tags.join('，')||''});
  const [photos,setPhotos]=useState<File[]>([]),[audio,setAudio]=useState<File|null>(null),[kept,setKept]=useState(memory?.assets||[]),[dirty,setDirty]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState('');
  useEffect(()=>{if(!memory)setValues(v=>({...v,nickname:localStorage.getItem('album_nickname')||''}));},[memory]);
  const previews=useMemo(()=>photos.map(file=>URL.createObjectURL(file)),[photos]);useEffect(()=>()=>previews.forEach(URL.revokeObjectURL),[previews]);
  const close=useCallback(()=>{if(!busy&&(!dirty||window.confirm(t('editor.confirmClose'))))onClose();},[busy,dirty,onClose,t]);
  const change=(key:string,value:string)=>{setValues(v=>({...v,[key]:value}));setDirty(true);};
  function addPhotos(files:FileList|null){if(!files)return;const selected=Array.from(files);if(selected.some(f=>!['image/jpeg','image/png','image/webp'].includes(f.type)||f.size>10*1024*1024)){setError('请选择 10 MB 以内的 JPG、PNG 或 WebP 照片。');return;}if(selected.length+photos.length+kept.filter(a=>a.kind.startsWith('image/')).length>9){setError('每条回忆最多 9 张照片。');return;}setPhotos(p=>[...p,...selected]);setDirty(true);setError('');}
  async function submit(e:React.FormEvent){e.preventDefault();if(busy)return;setError('');if(photos.reduce((s,f)=>s+f.size,0)+(audio?.size||0)>30*1024*1024){setError('本次附件合计不能超过 30 MB。');return;}setBusy(true);try{const data=new FormData();for(const [key,value]of Object.entries(values))data.set(key,value);data.set('keepAssets',JSON.stringify(kept.map(a=>a.id)));if(memory)data.set('revision',memory.updatedAt);photos.forEach(f=>data.append('photos',f));if(audio)data.set('audio',audio);await api(memory?'memories/'+memory.id:'memories',{method:memory?'PATCH':'POST',body:data});localStorage.setItem('album_nickname',values.nickname);onSaved();}catch(e){setError((e as Error).message);}finally{setBusy(false);}}
  const audioKept=kept.find(a=>a.kind.startsWith('audio/'));
  return <Modal title={memory?t('editor.edit'):t('editor.new')} onClose={close} wide><form className="editor-form" onSubmit={submit}>
    <p className="muted">{t('editor.intro')}</p>
    <label>{t('editor.title')} <span>*</span><input maxLength={80} required value={values.title} onChange={e=>change('title',e.target.value)} placeholder={t('editor.titlePlaceholder')}/></label>
    <div className="form-row"><label>{t('editor.nickname')} <span>*</span><input required maxLength={30} value={values.nickname} onChange={e=>change('nickname',e.target.value)} placeholder={t('editor.nicknamePlaceholder')}/></label><label>{t('editor.category')}<select value={values.category} onChange={e=>change('category',e.target.value)}>{groups.map(g=><option key={g.id} value={g.id}>{t('category.'+g.id)}</option>)}</select></label></div>
    <label>{t('editor.body')}<textarea maxLength={5000} rows={5} value={values.body} onChange={e=>change('body',e.target.value)} placeholder={t('editor.bodyPlaceholder')}/><small className="text-count">{values.body.length} / 5000</small></label>
    <label>{t('editor.friends')}<input maxLength={400} value={values.tags} onChange={e=>change('tags',e.target.value)} placeholder={t('editor.friendsPlaceholder')}/></label>
    <div className="field-title">{t('editor.photos')} <small>{t('editor.photoLimit')}</small></div><div className="upload-grid">
      {kept.filter(a=>a.kind.startsWith('image/')).map(a=><div className="upload-preview" key={a.id}><img src={a.url} alt="已保存的照片"/><button type="button" aria-label="移除这张照片" onClick={()=>{setKept(kept.filter(x=>x.id!==a.id));setDirty(true);}}><Icon name="close" size={14}/></button></div>)}
      {previews.map((url,i)=><div className="upload-preview" key={url}><img src={url} alt={'待上传照片 '+(i+1)}/><button type="button" aria-label={'移除照片 '+(i+1)} onClick={()=>{setPhotos(photos.filter((_,j)=>j!==i));setDirty(true);}}><Icon name="close" size={14}/></button></div>)}
      <label className="upload-tile"><Icon name="plus" size={25}/><span>{t('editor.addPhoto')}</span><input type="file" accept="image/jpeg,image/png,image/webp" multiple onChange={e=>{addPhotos(e.target.files);e.target.value='';}}/></label>
    </div>
    <div className="audio-upload"><Icon name="music"/><div><strong>{t('editor.audio')}</strong><small>{audio?.name||(audioKept?t('editor.audioKept'):t('editor.audioHint'))}</small></div>{audio||audioKept?<button type="button" className="text-button" onClick={()=>{setAudio(null);setKept(kept.filter(a=>!a.kind.startsWith('audio/')));setDirty(true);}}>{t('common.remove')}</button>:<label className="small-upload">{t('editor.chooseAudio')}<input type="file" accept="audio/mpeg,audio/mp4,audio/x-m4a,.mp3,.m4a" onChange={e=>{const f=e.target.files?.[0];if(f){if(f.size>20*1024*1024){setError('音乐文件最多 20 MB。');return;}setAudio(f);setDirty(true);}}}/></label>}</div>
    {error&&<p className="error-message" role="alert">{error}</p>}<footer className="form-footer"><span className="muted">{t('editor.footer')}</span><button className="primary-button" disabled={busy} type="submit"><Icon name={busy?'heart':'check'} size={18}/>{busy?t('editor.saving'):memory?t('editor.save'):t('editor.create')}</button></footer>
  </form></Modal>;
}
