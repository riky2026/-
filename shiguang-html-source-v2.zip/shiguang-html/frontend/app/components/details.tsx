'use client';
import {useCallback,useState} from 'react';
import {Memory,api} from '../../lib/types';
import {Icon,Modal} from './ui';
import {useCopy} from './copy';
export function Details({memory,onClose,onEdit,onDeleted,onAudio}:{memory:Memory;onClose:()=>void;onEdit:()=>void;onDeleted:()=>void;onAudio:()=>void}){
  const t=useCopy(),[zoom,setZoom]=useState<string|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState('');const closeZoom=useCallback(()=>setZoom(null),[]);
  const images=memory.assets.filter(a=>a.kind.startsWith('image/')),audio=memory.assets.find(a=>a.kind.startsWith('audio/'));
  async function remove(){if(!window.confirm(t('detail.confirmDelete')))return;setBusy(true);try{await api('memories/'+memory.id,{method:'DELETE'});onDeleted();}catch(e){setError((e as Error).message);setBusy(false);}}
  return <><Modal title={t('detail.title')} onClose={()=>{if(!busy)onClose();}} wide><article className="detail-content"><div className="detail-meta"><span className="category-label">{t('category.'+memory.category)}</span>{memory.example&&<span className="example-pill">{t('detail.sample')}</span>}</div><h1>{memory.title}</h1><p className="byline"><span className="avatar">{memory.nickname.slice(0,1)}</span>{memory.nickname}</p>
    {images.length>0&&<div className={'detail-gallery '+(images.length===1?'single':'')}>{images.map((a,i)=><button key={a.id} onClick={()=>setZoom(a.url)} aria-label={'放大照片 '+(i+1)}><img src={a.url} alt={memory.title+'，照片 '+(i+1)}/></button>)}</div>}
    <p className="story-body">{memory.body}</p>{audio&&<div className="story-audio"><Icon name="music"/><div><span>{t('detail.audio')}</span><audio controls src={audio.url} preload="none" onPlay={onAudio}/></div></div>}
    {!!memory.tags.length&&<div className="friend-tags"><Icon name="users" size={16}/>{memory.tags.map(tag=><span key={tag}>{tag}</span>)}</div>}
    {error&&<p className="error-message" role="alert">{error}</p>}{(memory.canEdit||memory.canDelete)&&<footer className="detail-actions">{memory.canEdit&&<button className="secondary-button" onClick={onEdit} disabled={busy}><Icon name="edit" size={17}/>{t('detail.edit')}</button>}{memory.canDelete&&<button className="text-button danger" onClick={remove} disabled={busy}><Icon name="trash" size={17}/>{busy?t('detail.deleting'):t('detail.delete')}</button>}</footer>}
    {memory.example&&<p className="example-note">{t('detail.sampleNote')}</p>}
  </article></Modal>{zoom&&<div className="lightbox" role="dialog" aria-modal="true" aria-label="照片放大查看" onClick={closeZoom} onKeyDown={e=>{if(e.key==='Escape'){e.stopPropagation();closeZoom();}if(e.key==='Tab')e.preventDefault();}}><button aria-label="关闭大图" onClick={closeZoom} autoFocus><Icon name="close" size={25}/></button><img src={zoom} alt="回忆照片大图" onClick={e=>e.stopPropagation()}/></div>}</>;
}
