'use client';
import {createContext,useContext} from 'react';
import {copyText} from '../../lib/copy';
export const CopyContext=createContext<Record<string,string>>({});
export function useCopy(){const values=useContext(CopyContext);return (key:string,args?:Record<string,string|number>)=>copyText(values,key,args);}
