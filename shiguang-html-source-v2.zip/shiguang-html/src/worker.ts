import {handleApi} from '../lib/server';
export default {
  async fetch(request:Request,env:{ASSETS:{fetch:(request:Request)=>Promise<Response>}}){
    const pathname=new URL(request.url).pathname;
    if(!pathname.startsWith('/api/'))return env.ASSETS.fetch(request);
    const response=await handleApi(request,pathname.slice(5).split('/').filter(Boolean));
    if(request.body&&!request.bodyUsed){
      const length=Number(request.headers.get('Content-Length')||0);
      if(length>0&&length<=65536)await request.arrayBuffer().catch(()=>{});
      else await request.body.cancel().catch(()=>{});
    }
    return response;
  },
};
